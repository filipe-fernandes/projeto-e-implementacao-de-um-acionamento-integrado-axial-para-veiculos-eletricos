#include "My_config.h"

interrupt void timerISR(void);


float Freq_limite = 150;
float t_on=3.0;
float t_off=3.0;
float t_rampa = 9.0;//segundos

float Freq_min = 15.0;
int Freq_sine = 0;
float Freq_sinef = 0.0;
float Freq_nom = 150.0;
int flag_reset = 0;
float t_s = 0.0;
float theta = 0.0;
float newDuty = 1000.0;
float newFrequ = 150.0;
float c=2.0;
float phi=0.0;
float comp_phi=0.0;
int trava=1;
int resume_rampa=0;
float tn_on=0;
float d_theta=0;
//float tempsine=40000.0, sineDant=0.0;

float sineA = 0;
float sineAA = 0;
float sineB = 0;
float sineBB = 0;
float sineC = 0;
float sineCC = 0;
float sineD = 0;
float sineDD = 0;

int time=0;
uint32_t newPWM1Duty = 0;

//Global Variables
uint16_t can_rxMsg[8] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
uint16_t can_error = 0;
//uint16_t can_txMsg[8] = {0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8};
//uint16_t can_txMsg2[8] = {0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8};
uint32_t Freq = 150; //Est� sendo definida duas vezes a frequ�ncia, em Freq e em FTIMER no header dos timers
uint16_t gDuty = 500;
uint32_t newPWM1_Dval=0, newPWM1_Fval=0;
uint16_t RX_can_pack_rcv=0;  //definida em My_config.h
//uint16_t can_responseMsg[8] = {0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0};
#define ERROR_PIN       GpioDataRegs.GPHDAT.bit.GPIO228 //GPIO A6C6 AIO228 (INPUT) erro em nivel logico alto (pino 4 do DSP, sinaliza qualquer erro, eh uma operacao logica E do erro de todos os drivers, mais ERR_DSP, ERR_ST (sobretensao) e ERR_SNB
#define RESET_PIN       GpioDataRegs.GPADAT.bit.GPIO16  //GPIO16 (OUTPUT) (pino 26 do DSP, reset com nivel alto)
#define DISABLE_PWM     GpioDataRegs.GPADAT.bit.GPIO24  //GPIO24 (OUTPUT) pino 24 do DSP, ERR_DSP (disable com nivel alto)

uint8_t ErrorState = 0xFF; //armazena o estado atual do erro para comparacao de transicoes

ADC_buffer adc_buffer;
uint16_t plot_ADC[ADC_SAMPLE];
uint16_t plot_index=0;
uint16_t *adc = &adc_buffer.Io4;

void main(void)
{
  InitSysCtrl();      //Initialize System
  DINT;               //Disable CPU interrupts
  InitPieCtrl();      //Initialize the PIE control registers to their default state
  IER = 0x000;        //Clear all CPU interrupts
  IFR = 0x000;        //Clear all interrupts flags
  InitPieVectTable(); //Initialize the PIE vector table
  EINT;               //Enable Global interrupt INTM
  ERTM;               //Enable Global real time interrupt DBGM

  Setup_GPIOs();
  Setup_ePWM();
  Setup_CAN();
  Setup_ADC();
  Setup_Timer0();

  // Configura��o do vetor de interrup��o para Timer 0
    EALLOW;
    PieVectTable.TIMER0_INT = &timerISR;

    // Configura��o da interrup��o do Timer 0
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;  // Habilita a interrup��o do Timer 0
    IER |= M_INT1;  // Habilita interrup��es do Grupo 1

    EDIS;

    // Habilita interrup��es globais
    EINT;
    ERTM;               //Enable Global real time interrupt DBGM

#define TEMPO_ATUALIZA 1000000
  uint32_t SendValuesCounter = TEMPO_ATUALIZA;
  DISABLE_PWM = 1;
//  char PWM_disabled_flag = 1;

  //minhas vari�veis locais
  t_rampa= t_rampa*Freq_nom/Freq_limite;
  t_off= t_off*Freq_nom/Freq_limite;
  /*###############################################
    COME�A O LOOP
    ###############################################
  */
  for(;;){
      // error pin management
      if (SendValuesCounter==0){
          if (ERROR_PIN){
//              if (ErrorState != 0x01)  //se tem erro e nao tinha
//              {
//                  can_responseMsg[0] = 0x12; can_responseMsg[1] = 0x10;
//                  can_responseMsg[2] = 0; can_responseMsg[3] = 0; can_responseMsg[4] = 0; can_responseMsg[5] = 0;
//                  can_responseMsg[6] = 0;
//                  can_responseMsg[7] = 0x01;
//                  CAN_sendMessage(CANA_BASE, TX_OBJ_ID, MSG_DATA_LENGTH, can_responseMsg);
//              }
              //fazer mais alguma coisa se erro, por exemplo ATIVAR o pino DISABLE e DESligar os PWM
              ErrorState = 0x01;
          }
          else     //(!ERROR_PIN)
          {
              if (ErrorState != 0x00)  //se nao tem erro mas antes tinha
              {
//                  can_responseMsg[0] = 0x12; can_responseMsg[1] = 0x10;
//                  can_responseMsg[2] = 0; can_responseMsg[3] = 0; can_responseMsg[4] = 0; can_responseMsg[5] = 0;
//                  can_responseMsg[6] = 0x00;
//                  can_responseMsg[7] = 0x00;
//                  CAN_sendMessage(CANA_BASE, TX_OBJ_ID, MSG_DATA_LENGTH, can_responseMsg);
                  ErrorState = 0x00;
                  //fazer mais alguma coisa se zerou o erro, por exemplo DESativar o pino DISABLE e REligar os PWM
                  RESET_PIN = 1;
                  DELAY_US(200000);
                  RESET_PIN = 0;
              }
          }
          //      DELAY_US(200000);
      }
      if(resume_rampa==1){
          trava=0;
          resume_rampa=0;
          Freq_sinef=0;
          tn_on=0;
          d_theta=0;
      }
      if (newPWM1_Fval == 0 ) newPWM1_Fval = UINT16_UPPER_PWM_COUNTER;
      //set duty cycle
      //##############################

//             newDuty=1000;
             uint16_t u16loc_newPWM1Duty = newDuty;
//             uint16_t u16loc_newPWM1Duty = 0;
             if (u16loc_newPWM1Duty >= 999) u16loc_newPWM1Duty = 999;

             if (u16loc_newPWM1Duty == 0 || trava==1){
                 DISABLE_PWM = 1;
             }
             else{
                 DISABLE_PWM = 0;
             }

             if (u16loc_newPWM1Duty != gDuty){
                 newPWM1_Dval = (newPWM1_Fval);
                 newPWM1_Dval = newPWM1_Dval * u16loc_newPWM1Duty;
                 newPWM1_Dval = newPWM1_Dval /1000;
                 gDuty = u16loc_newPWM1Duty;
                 newPWM1Duty = gDuty;
             }
             else{
                 //set Frequency
                 uint32_t newPWM1Freq = newFrequ;
                 newPWM1Freq = newPWM1Freq *10; //65535 = 655.350 Hz (655,35 kHz) (resolucao 10 Hz)
                 if (newPWM1Freq >= 500000) newPWM1Freq = 500000;  //saturando em 500 kHz

                 if (newPWM1Freq != Freq){
                     newPWM1_Fval = FCPU/(2*PRESC*newPWM1Freq);    //variavel que armazena o maximo valor do contador PWM

                     newPWM1_Dval = (newPWM1_Fval); //Atualiza o valor do Duty cycle
                     newPWM1_Dval = newPWM1_Dval*gDuty;
                     newPWM1_Dval = newPWM1_Dval /1000;
                     EALLOW;
                     EPwm1Regs.TBPRD = (uint16_t)newPWM1_Fval; //atualiza o contador pra alterar a frequencia
                     EPwm2Regs.TBPRD = (uint16_t)newPWM1_Fval;
                     EPwm3Regs.TBPRD = (uint16_t)newPWM1_Fval;
                     EPwm4Regs.TBPRD = (uint16_t)newPWM1_Fval;

                     CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1; //Enable counter clock
                     EDIS;
                     Freq = newPWM1Freq;
                 }
             }
      //##############################
             if (flag_reset==1){        //Reset ERROR
                 flag_reset=0;
                 RESET_PIN = 1;
                 //DELAY_US(10000000);
                 DELAY_NS(500);
                 RESET_PIN = 0;
             }

      if (SendValuesCounter>0) SendValuesCounter--;
          else{
              //uint32_t FreqResp = (uint32_t)Freq/10;
              SendValuesCounter = TEMPO_ATUALIZA;
          }
          //ANS fim alteracoes
  }
  /*###############################################
    ACABA O LOOP
    ###############################################
  */
}
/*###############################################
  ACABA O MAIN
  ###############################################
*/

// Fun��o de tratamento de interrup��o para o Timer 0
interrupt void timerISR(void)
{
    //GpioDataRegs.GPADAT.bit.GPIO5 = 1;
//    GpioDataRegs.GPATOGGLE.bit.GPIO5 = 1;

    sineA = newPWM1Duty * sinf(theta)/2.0f;
    sineAA = newPWM1_Fval * (sineA+500)/1000;
    PWM1 = sineAA;
    //PWM4 = sineAA;

    sineB = newPWM1Duty * sinf(theta -(120.0f*M_PI/180.0f))/2.0f;
    sineBB = newPWM1_Fval * (sineB+500)/1000;
    //PWM3 = sineBB;
    PWM2 = sineBB;

    sineC = newPWM1Duty * sinf(theta +(120.0f*M_PI/180.0f))/2.0f;
    sineCC = newPWM1_Fval * (sineC+500)/1000;
    PWM3 = sineCC;

//    PWM5 = sineAA;
//    PWM4 = sineAA;
//    PWM3 = sineBB;
//    PWM2 = sineBB;
//    PWM1 = sineCC;
//    PWM6 = sineCC;

    //sineD = sinf(2*M_PI*Freq_sine*time/(FTIMER*1000)+comp_phi);
    sineD = sinf(theta);
    if(sineD>0.5){
        sineDD=40000;
        }
    else{
        sineDD=0;
    }

    PWM6 = sineDD;

    time++;

    if(time>=(FTIMER*1000)){
        time=0;
        comp_phi=comp_phi+2*M_PI*Freq_limite;

        while(comp_phi>M_PI){
            comp_phi-=2*M_PI;
        }
        if(Freq_sinef>=Freq_limite){
            tn_on++;
        }
//        if(sineDD==0){
//              sineDD=40000;
//              }
//          else{
//              sineDD=0;
//          }
    }
//    if(time>tmax){
//        tmax=time;
//    }
//###################################################
//  Forma antiga de fazer a rampa
//    Freq_sinef+=0.1/t_rampa;
//    if(Freq_sinef >= Freq_nom){
//        Freq_sinef = Freq_nom;
//        c=2;
//        phi=-M_PI*Freq_nom*t_rampa;
//    }
//    Freq_sine = (int)Freq_sinef*c/2;
//    Freq_sine = Freq_nom;

//  Forma NOVA
    //tn_on=0;
    if(tn_on>1.5*t_on/2){
        theta = (2*M_PI*Freq_limite*time/(FTIMER*1000))+comp_phi-d_theta;
        newDuty=newDuty-0.6/(t_off);
        if(newDuty<=0) newDuty=0;
    }
    else{
        if(t_rampa<1) t_rampa=1.0;
        if(Freq_sinef<0) Freq_sinef=0.0;
        Freq_sinef+=0.1/t_rampa;
        if(Freq_sinef>Freq_limite){
            Freq_sinef=Freq_limite;
            t_s=t_rampa;
            //phi=-M_PI*Freq_limite*t_rampa*Freq_limite/Freq_nom;
            if(d_theta==0.0){
                d_theta=(2*M_PI*Freq_limite*time/(FTIMER*1000))+comp_phi-(M_PI*Freq_limite*t_s*t_s/t_rampa*Freq_limite/Freq_nom);
            }
            theta = (2*M_PI*Freq_limite*time/(FTIMER*1000))+comp_phi-d_theta;
        }
        else{
            t_s=Freq_sinef/Freq_limite*t_rampa;
            theta=M_PI*Freq_limite*t_s*t_s/t_rampa*Freq_limite/Freq_nom;
        }
//          if(Freq_sinef<Freq_min){
//              newDuty=1000*Freq_min/Freq_nom/2.0*(1.0+Freq_sinef/Freq_min);
//          }
//          if(Freq_sinef>Freq_min){
              newDuty=1000*Freq_sinef/Freq_nom;
//          }
    }
    //Freq_sine = (int)Freq_sinef;
    //Freq_sine = Freq_nom;

    //GpioDataRegs.GPADAT.bit.GPIO5 = 0;
    //GpioDataRegs.GPATOGGLE.bit.GPIO5 = 1;
    // Sua l�gica de tratamento de interrup��o aqui
    // Limpa a bandeira de interrup��o do Timer 0
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}
