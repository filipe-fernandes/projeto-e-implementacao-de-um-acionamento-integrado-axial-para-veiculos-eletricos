/*
 * Communications.h
 *
 *  Created on: 13 de jul de 2023
 *      Author: Projeto
 */

#ifndef MY_HEADERS_CONFIG_CAN_H_
#define MY_HEADERS_CONFIG_CAN_H_

#include "driverlib.h"
#include "MyDefinitions.h"

//Config CAN Messages
#define MSG_DATA_LENGTH     0x08
#define RX_OBJ_ID           0x1      //Internal Memory Receive ID
#define TX_OBJ_ID           0x2      //Internal Memory Transmitter ID

#define TX_MSG_ID           0x702    //ID send Messages
#define RX_MSG_ID           0x601    //ID filter receive Messages
#define FCAN                500000                          //CAN frequency Transmission
//#define                   CAN_FRAME CAN_MSG_FRAME_STD     //Standard ID frame
#define CAN_FRAME           CAN_MSG_FRAME_EXT               //Extended ID frame




//Enable Communication
#define CAN ENABLE

//Enable Receive Interrupt
#define CAN_RECEICE_MSG_INTERRUPT ENABLE

//Global Variables
extern uint16_t can_rxMsg[8];
extern uint16_t can_txMsg[8];
extern uint16_t can_error;

//External Functions
extern void Setup_CAN(void);

//External Interrupt Functions
extern __interrupt void canISR(void);


#endif /* MY_HEADERS_CONFIG_CAN_H_ */
