/*
 * MyDefinitions.h
 *
 *  Created on: 1 de ago de 2023
 *      Author: Projeto
 */

#ifndef MY_HEADERS_MYDEFINITIONS_H_
#define MY_HEADERS_MYDEFINITIONS_H_

//---------------------Initial Definitions--------------------------------
#define INPUT 0
#define OUTPUT 1
#define ENABLE 2
#define DISABLE 3




#endif /* MY_HEADERS_MYDEFINITIONS_H_ */
