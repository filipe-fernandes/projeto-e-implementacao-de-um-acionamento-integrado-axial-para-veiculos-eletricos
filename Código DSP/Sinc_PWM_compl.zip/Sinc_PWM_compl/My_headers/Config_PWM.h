/*
 * Config_PWM.h
 *
 *  Created on: 13 de jul de 2023
 *      Author: Projeto
 */

#ifndef MY_HEADERS_CONFIG_PWM_H_
#define MY_HEADERS_CONFIG_PWM_H_

#include "f28003x_device.h"
#include "f28003x_globalprototypes.h"
#include "MyDefinitions.h"

//Define general setup PWM's outputs
#define FPWM    100e3   //PWM frequency
#define FCPU    120e6   //CPU Frequency
#define PRESC   1       //Prescale
#define UINT16_UPPER_PWM_COUNTER  FCPU/(2*PRESC*FPWM) //for timer upper_down

//Define PWM comparator signal output
#define PWM1 EPwm3Regs.CMPA.bit.CMPA
#define PWM2 EPwm2Regs.CMPA.bit.CMPA
#define PWM3 EPwm2Regs.CMPB.bit.CMPB
#define PWM4 EPwm1Regs.CMPA.bit.CMPA
#define PWM5 EPwm1Regs.CMPB.bit.CMPB
#define PWM6 EPwm4Regs.CMPB.bit.CMPB

//-----------------------Enable PWM's Pins---------------------------------
#define OUTPUT_PWM1 ENABLE
#define OUTPUT_PWM2 ENABLE
#define OUTPUT_PWM3 ENABLE
#define OUTPUT_PWM4 ENABLE
#define OUTPUT_PWM5 ENABLE
#define OUTPUT_PWM6 ENABLE
#define OUTPUT_PWM7 ENABLE


//External Functions
extern void Setup_ePWM(void);

#endif /* MY_HEADERS_CONFIG_PWM_H_ */
