/*
 * Setup_IOs.h
 *
 *  Created on: 13 de jul de 2023
 *      Author: Projeto
 */

#ifndef MY_HEADERS_MY_CONFIG_H_
#define MY_HEADERS_MY_CONFIG_H_

#include "f28003x_device.h"
#include "f28003x_globalprototypes.h"
#include "f28003x_epwm_defines.h"
#include "f28003x_examples.h"
#include "MyDefinitions.h"
#include "driverlib.h"
#include "Config_PWM.h"
#include "Config_CAN.h"
#include "Config_SCI.h"
#include "Config_ADC.h"
#include "Config_Timers.h"
#include "Math.h"

#define DELAY_NS(A)  F28x_usDelay(((((long double) A * 1.0L) / (long double)CPU_RATE) - 9.0L) / 5.0L)

//--------------------Enable Communication--------------------------------
#define JTAG ENABLE


//-----------------Function Generic Digital IO's---------------------------
#define DIR_IN_OUT1 OUTPUT  //GPIO5
#define DIR_IN_OUT2 OUTPUT  //GPIO6

#if CAN==ENABLE
    #define DIR_IN_OUT3 CAN     //GPIO32
    #define DIR_IN_OUT4 CAN     //GPIO33
#else
    #define DIR_IN_OUT3 INPUT     //GPIO32
    #define DIR_IN_OUT4 INPUT     //GPIO33
#endif

#if SCI==ENABLE
    #define DIR_IN_OUT5 JTAG    //GPIO35
    #define DIR_IN_OUT6 JTAG    //GPIO37
#else
    #define DIR_IN_OUT5 INPUT    //GPIO35
    #define DIR_IN_OUT6 INPUT    //GPIO37
#endif


//-------------------Prototypes and Global Variables---------------------

//External Functions
extern void Setup_GPIOs(void);


//ANS External variables
extern uint16_t RX_can_pack_rcv;


#endif /* MY_HEADERS_MY_CONFIG_H_ */
