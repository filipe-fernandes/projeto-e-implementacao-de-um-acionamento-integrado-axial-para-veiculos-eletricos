/*
 * Config_ADC.h
 *
 *  Created on: 31 de jul de 2023
 *      Author: Projeto
 */

#ifndef MY_HEADERS_CONFIG_ADC_H_
#define MY_HEADERS_CONFIG_ADC_H_

#include "MyDefinitions.h"

//-------------------------Definitions----------------------------
#define ADC_TRIGGER_TIMER0 0x01 //Define Sample Frequency in Config_Timer.h
#define ADC_TRIGGER_EPWM8 0x14  //Non Implemented



//----------------------Enable ADC Interrupts----------------------
#define ADC_FINISH_CONVERSION_INTERRUPT ENABLE


//-----------------------Source Trigger ADC-----------------------
#define ADC_TRIGGER_SOURCE ADC_TRIGGER_TIMER0


//-----------------------Enable plot vector------------------------
#define PLOT_ADC_VECTOR ENABLE
#define ADC_SAMPLE 100







//-------------------Prototypes and Global Variables---------------
typedef struct{
    uint16_t Io1;     //CH_A12
    uint16_t Io2;     //CH_A11
    uint16_t Io3;     //CH_A8
    uint16_t Io4;     //CH_A1
    uint16_t Vo1;     //CH_A0
    uint16_t Vo2;     //CH_A15
    uint16_t Vo3;     //CH_A7
    uint16_t Vo4;     //CH_A4
    uint16_t Vref;    //CH_A5
    uint16_t Vdc_p;   //CH_A9
    uint16_t Vdc_n;   //CH_A10
}ADC_buffer;

extern ADC_buffer adc_buffer;

#if PLOT_ADC_VECTOR==ENABLE
    extern uint16_t plot_ADC[ADC_SAMPLE];
    extern uint16_t plot_index;
    extern uint16_t *adc;
#endif

//External Functions
extern void Setup_ADC(void);

//External Interrupt
extern __interrupt void AdcISR(void);

#endif /* MY_HEADERS_CONFIG_ADC_H_ */
