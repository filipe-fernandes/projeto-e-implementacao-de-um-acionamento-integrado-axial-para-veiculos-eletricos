/*
 * Config_SCI.h
 *
 *  Created on: 1 de ago de 2023
 *      Author: Projeto
 */

#ifndef MY_HEADERS_CONFIG_SCI_H_
#define MY_HEADERS_CONFIG_SCI_H_

#include "MyDefinitions.h"

#define SCI ENABLE

//----------------------Enable Interrupts----------------------------------
#define SCI_RECEIVE_DATA_INTERRUPT DISABLE



#endif /* MY_HEADERS_CONFIG_SCI_H_ */
