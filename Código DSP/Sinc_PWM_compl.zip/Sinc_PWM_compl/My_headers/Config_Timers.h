/*
 * Config_Timers.h
 *
 *  Created on: 31 de jul de 2023
 *      Author: Projeto
 */

#ifndef MY_HEADERS_CONFIG_TIMERS_H_
#define MY_HEADERS_CONFIG_TIMERS_H_

#include "MyDefinitions.h"




//----------------------Timer Parameters--------------------------
#define FSYS    120   //CPU Frequency in MHz
#define FTIMER  1.5     //TIMER Frequency in kHz

//Calculate Period in us
#define PTIMER  (1000/FTIMER)


//-------------------Enable Timer Interrupt------------------------
#define OVF_TIMER0_INTERRUPT DISABLE




//-------------------Prototypes and Global Variables---------------
extern void Setup_Timer0(void);


//External interrupt Functions
extern __interrupt void timer0ISR(void);


#endif /* MY_HEADERS_CONFIG_TIMERS_H_ */
