/*
 * Setup_Timers.c
 *
 *  Created on: 31 de jul de 2023
 *      Author: Projeto
 */
#include "My_config.h"


void Setup_Timer0(void){

    EALLOW;

    //Disable clock timer 0
    CpuSysRegs.PCLKCR0.bit.CPUTIMER0 = 1;

    //Configure Timer 0 interrupt
    #if OVF_TIMER0_INTERRUPT==ENABLE
      PieVectTable.TIMER0_INT =  &timer0ISR;  //Interrupt_register(INT_TIMER0, &timer0ISR);
      PieCtrlRegs.PIEIER1.bit.INTx7 = 1;      //Interrupt_enable(INT_TIMER0);
      IER |=M_INT1;
    #endif

    //Initialize timers
    InitCpuTimers();

    //Configure Timer 0
   ConfigCpuTimer(&CpuTimer0, FSYS, PTIMER);

    //Enable Timer 0 interrupt
    CpuTimer0Regs.TCR.all = 0x4000; //TIE=1 and TSS=0

    EDIS;
}
