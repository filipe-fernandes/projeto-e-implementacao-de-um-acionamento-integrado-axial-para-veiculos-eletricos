/*
 * My_interrupts.c
 *
 *  Created on: 13 de jul de 2023
 *      Author: Projeto
 */

#include "My_config.h"

extern uint16_t RX_can_pack_rcv;    //ANS flag para sinalizar pacote CAN pro main

__interrupt void canISR(void){
    uint32_t status;

    //
    // Read the CAN interrupt status to find the cause of the interrupt
    //
    status = CAN_getInterruptCause(CANA_BASE);

    //
    // If the cause is a controller status interrupt, then get the status
    //
    if(status == CAN_INT_INT0ID_STATUS)
    {
        //
        // Read the controller status.  This will return a field of status
        // error bits that can indicate various errors.  Error processing
        // is not done in this example for simplicity.  Refer to the
        // API documentation for details about the error status bits.
        // The act of reading this status will clear the interrupt.
        //
        status = CAN_getStatus(CANA_BASE);

        //
        // Check to see if an error occurred.
        //
        if(((status  & ~(CAN_STATUS_TXOK | CAN_STATUS_RXOK)) != 7) &&
           ((status  & ~(CAN_STATUS_TXOK | CAN_STATUS_RXOK)) != 0))
        {
            //
            // Set a flag to indicate some errors may have occurred.
            //
            can_error = 1;
        }
    }

    //
    // Check if the cause is the transmit message object 1
    //
    else if(status == TX_OBJ_ID)
    {
        //
        // Getting to this point means that the TX interrupt occurred on
        // message object 1, and the message TX is complete.  Clear the
        // message object interrupt.
        //
        CAN_clearInterruptStatus(CANA_BASE, TX_OBJ_ID);

        //
        // Increment a counter to keep track of how many messages have been
        // sent.  In a real application this could be used to set flags to
        // indicate when a message is sent.
        //


        //
        // Since the message was sent, clear any error flags.
        //
        can_error = 0;
    }

    //teste TX_OBJ +1
    else if(status == TX_OBJ_ID+1)
    {
        CAN_clearInterruptStatus(CANA_BASE, TX_OBJ_ID+1);
        can_error = 0;
    }


    //
    // Check if the cause is the receive message object 2
    //
    else if(status == RX_OBJ_ID)
    {
        //
        // Get the received message
        //
        CAN_readMessage(CANA_BASE, RX_OBJ_ID, can_rxMsg);

        //
        // Getting to this point means that the RX interrupt occurred on
        // message object 2, and the message RX is complete.  Clear the
        // message object interrupt.
        //
        CAN_clearInterruptStatus(CANA_BASE, RX_OBJ_ID);

        RX_can_pack_rcv = 1;

        //
        // Increment a counter to keep track of how many messages have been
        // received. In a real application this could be used to set flags to
        // indicate when a message is received.
        //

        //
        // Since the message was received, clear any error flags.
        //
        can_error = 0;
    }

    //
    // If something unexpected caused the interrupt, this would handle it.
    //
    //else
    {
        //
        // Spurious interrupt handling can go here.
        //
    }

    //
    // Clear the global interrupt flag for the CAN interrupt line
    //
    CAN_clearGlobalInterruptStatus(CANA_BASE, CAN_GLOBAL_INT_CANINT0);

    //
    // Acknowledge this interrupt located in group 9
    //
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP9);
}



__interrupt void timer0ISR(void){

    // Acknowledge this interrupt located in group 1
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}


__interrupt void AdcISR(void){

    adc_buffer.Vo1 = AdcaResultRegs.ADCRESULT0;
    adc_buffer.Io4 = AdcaResultRegs.ADCRESULT1;
    adc_buffer.Vo4 = AdcaResultRegs.ADCRESULT2;
    adc_buffer.Vref = AdcaResultRegs.ADCRESULT3;
    adc_buffer.Vo3 = AdcaResultRegs.ADCRESULT4;
    adc_buffer.Io3 = AdcaResultRegs.ADCRESULT5;
    adc_buffer.Vdc_p = AdcaResultRegs.ADCRESULT6;
    adc_buffer.Vdc_n = AdcaResultRegs.ADCRESULT7;
    adc_buffer.Io2 = AdcaResultRegs.ADCRESULT8;
    adc_buffer.Io1 = AdcaResultRegs.ADCRESULT9;
    adc_buffer.Vo2 = AdcaResultRegs.ADCRESULT10;


    #if PLOT_ADC_VECTOR==ENABLE

        plot_ADC[plot_index] = *adc;        //ANS estava escrevendo no indice 100
//        if(plot_index<ADC_SAMPLE)         //ANS estava escrevendo no indice 100
        if(plot_index<ADC_SAMPLE-1)         //ANS FIX estava escrevendo no indice 100
            plot_index++;
        else
           plot_index=0;
    #endif

    AdcaRegs.ADCINTOVFCLR.bit.ADCINT1 = 1; //Clear overflow flag
    AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;  // Make sure INT1 flag is cleared
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1; // Acknowledge this interrupt located in group 1
}

