/*
 * Setup_ePWM.c
 *
 *  Created on: 31 de jul de 2023
 *      Author: Projeto
 */

#include "My_config.h"

void Setup_ePWM(void)
{
    EALLOW;
    CpuSysRegs.PCLKCR2.bit.EPWM1 = 1;     //Enable clock ePWM1
    CpuSysRegs.PCLKCR2.bit.EPWM2 = 1;     //Enable clock ePWM2
    CpuSysRegs.PCLKCR2.bit.EPWM3 = 1;     //Enable clock ePWM3
    CpuSysRegs.PCLKCR2.bit.EPWM4 = 1;     //Enable clock ePWM4

    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 0; //Disable counter clock

    //Initialize PWM counter
    EPwm1Regs.TBCTR = 0;
    EPwm2Regs.TBCTR = 0;
    EPwm3Regs.TBCTR = 0;
    EPwm4Regs.TBCTR = 0;

    //Define PWM counter limit
    EPwm1Regs.TBPRD = UINT16_UPPER_PWM_COUNTER;
    EPwm2Regs.TBPRD = UINT16_UPPER_PWM_COUNTER;
    EPwm3Regs.TBPRD = UINT16_UPPER_PWM_COUNTER;
    EPwm4Regs.TBPRD = UINT16_UPPER_PWM_COUNTER;

    //Enable Shift Phase
    EPwm1Regs.TBCTL.bit.PHSEN = TB_ENABLE;
    //EPwm1Regs.TBCTL.bit.PHSEN = TB_ENABLE;
    EPwm2Regs.TBCTL.bit.PHSEN = TB_ENABLE;
    EPwm3Regs.TBCTL.bit.PHSEN = TB_ENABLE; //TB_DISABLE;
    EPwm4Regs.TBCTL.bit.PHSEN = TB_ENABLE;

    //Determine Master Sync Phase Shift PWM
    EPwm3Regs.EPWMSYNCOUTEN.bit.ZEROEN = 1; //PWM1 is master

    //Determine Slaves Sync Phase Shift PWM
    EPwm1Regs.EPWMSYNCINSEL.bit.SEL=3; //PWM4 and PWM5 are slaves
    EPwm2Regs.EPWMSYNCINSEL.bit.SEL=3; //PWM2 is slave
    EPwm4Regs.EPWMSYNCINSEL.bit.SEL=1; //PWM6 is slave

    //Value Shift Phase: TBPHS=PHASE( )/180*UINT16_UPPER_PWM_COUNTER
    EPwm1Regs.TBPHS.bit.TBPHS = 0;    //PWM5 -> 0
    EPwm2Regs.TBPHS.bit.TBPHS = 0; // UINT16_UPPER_PWM_COUNTER/2;  //PWM3 -> 90
    EPwm3Regs.TBPHS.bit.TBPHS = 0;                           //PWM1 -> 0 
    EPwm4Regs.TBPHS.bit.TBPHS = 0; // UINT16_UPPER_PWM_COUNTER/2;  //PWM6 -> -90

    //Direction Shift Phase
    EPwm1Regs.TBCTL.bit.PHSDIR = 0; //Positive angle
    EPwm2Regs.TBCTL.bit.PHSDIR = 0; //Positive angle
    EPwm3Regs.TBCTL.bit.PHSDIR = 0; //Positive angle
    EPwm4Regs.TBCTL.bit.PHSDIR = 0; //Positive angle //1; //Negative angle

    //Carrier Mode (UP, DOWN or UPDOWN)
    EPwm1Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;
    EPwm2Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;
    EPwm3Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;
    EPwm4Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;

    //Select Prescale 1 (HSPCLKDIV and CLKDIV)
    EPwm1Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;
    EPwm2Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;
    EPwm3Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;
    EPwm4Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;

    EPwm1Regs.TBCTL.bit.CLKDIV = TB_DIV1;
    EPwm2Regs.TBCTL.bit.CLKDIV = TB_DIV1;
    EPwm3Regs.TBCTL.bit.CLKDIV = TB_DIV1;
    EPwm4Regs.TBCTL.bit.CLKDIV = TB_DIV1;

    //Upgrade Points Comparator PWM (TBCTR=0 or TBCTR=UPPER_PWM_COUNTER)
    EPwm1Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm1Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;
    EPwm1Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm1Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;

    EPwm2Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm2Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;
    EPwm2Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm2Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;

    EPwm3Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm3Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;
    EPwm3Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm3Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;

    EPwm4Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm4Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;
    EPwm4Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm4Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;

    //Config Comparators for ePWMs
    //For PWM5 (Use comparator CMPB)
    EPwm1Regs.AQCTLA.bit.CBU = AQ_SET;//mudado
    EPwm1Regs.AQCTLA.bit.CBD = AQ_CLEAR;//mudado
    EPwm1Regs.AQCTLA.bit.PRD = AQ_NO_ACTION;
    EPwm1Regs.AQCTLA.bit.ZRO = AQ_NO_ACTION;

    //For PWM4 (Use comparator CMPA)
    EPwm1Regs.AQCTLB.bit.CAU = AQ_CLEAR;
    EPwm1Regs.AQCTLB.bit.CAD = AQ_SET;
    EPwm1Regs.AQCTLB.bit.PRD = AQ_NO_ACTION;
    EPwm1Regs.AQCTLB.bit.ZRO = AQ_NO_ACTION;

    //For PWM2 (Use comparator CMPA)
    EPwm2Regs.AQCTLA.bit.CBU = AQ_CLEAR;
    EPwm2Regs.AQCTLA.bit.CBD = AQ_SET;
    EPwm2Regs.AQCTLA.bit.PRD = AQ_NO_ACTION;
    EPwm2Regs.AQCTLA.bit.ZRO = AQ_NO_ACTION;

    //For PWM3 (Use comparator CMPB)
    EPwm2Regs.AQCTLB.bit.CAU = AQ_CLEAR;
    EPwm2Regs.AQCTLB.bit.CAD = AQ_SET;
    EPwm2Regs.AQCTLB.bit.PRD = AQ_NO_ACTION;
    EPwm2Regs.AQCTLB.bit.ZRO = AQ_NO_ACTION;

    //For PWM1 (Use comparator CMPA)
    EPwm3Regs.AQCTLA.bit.CAU = AQ_CLEAR;
    EPwm3Regs.AQCTLA.bit.CAD = AQ_SET;
    EPwm3Regs.AQCTLA.bit.PRD = AQ_NO_ACTION;
    EPwm3Regs.AQCTLA.bit.ZRO = AQ_NO_ACTION;

    //For PWM6 (Use comparator CMPB)
    EPwm4Regs.AQCTLB.bit.CBU = AQ_CLEAR;
    EPwm4Regs.AQCTLB.bit.CBD = AQ_SET;
    EPwm4Regs.AQCTLB.bit.PRD = AQ_NO_ACTION;
    EPwm4Regs.AQCTLB.bit.ZRO = AQ_NO_ACTION;

    // Deadband - PWM1 AB
    EPwm1Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
    EPwm1Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;
    EPwm1Regs.DBCTL.bit.IN_MODE = DBA_ALL;
    EPwm1Regs.DBRED.bit.DBRED = 150;
    EPwm1Regs.DBFED.bit.DBFED = 150;

    // Deadband - PWM2 AB
    EPwm2Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;
    EPwm2Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;
    EPwm2Regs.DBCTL.bit.IN_MODE = DBA_ALL;
    EPwm2Regs.DBRED.bit.DBRED = 150;
    EPwm2Regs.DBFED.bit.DBFED = 150;

    // Deadband - PWM3 AB
    EPwm3Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
    EPwm3Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;
    EPwm3Regs.DBCTL.bit.IN_MODE = DBA_ALL;
    EPwm3Regs.DBRED.bit.DBRED = 150;
    EPwm3Regs.DBFED.bit.DBFED = 150;

    // Deadband - PWM4 AB
    EPwm4Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
    EPwm4Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;
    EPwm4Regs.DBCTL.bit.IN_MODE = DBB_ALL;
    EPwm4Regs.DBRED.bit.DBRED = 150;
    EPwm4Regs.DBFED.bit.DBFED = 150;

    //Initilize duty cicle
    EPwm1Regs.CMPA.bit.CMPA = 0;
    EPwm2Regs.CMPA.bit.CMPA = 0;
    EPwm3Regs.CMPA.bit.CMPA = 0;
    EPwm4Regs.CMPA.bit.CMPA = 0;
    EPwm1Regs.CMPB.bit.CMPB = 0;
    EPwm2Regs.CMPB.bit.CMPB = 0;
    EPwm3Regs.CMPB.bit.CMPB = 0;
    EPwm4Regs.CMPB.bit.CMPB = 0;

    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1; //Enable counter clock
    EDIS;
}


