/*
 * Setup_CAN.c
 *
 *  Created on: 31 de jul de 2023
 *      Author: Projeto
 */

#include "My_config.h"


void Setup_CAN(void)
{
    EALLOW;
    #if CAN==ENABLE
        CpuSysRegs.PCLKCR10.bit.CAN_A = 1;

        //Initialize CANA Controller
        CAN_initModule(CANA_BASE);

        // Set up the CAN bus bit rate to 500kbps
        CAN_setBitRate(CANA_BASE, FCPU, FCAN, 20);

        // Enable interrupts on the CAN peripheral.
        CAN_enableInterrupt(CANA_BASE, CAN_INT_IE0 | CAN_INT_ERROR | CAN_INT_STATUS);

        Interrupt_initModule();      // Initialize PIE and clear PIE registers. Disables CPU interrupts
        Interrupt_initVectorTable(); //Initialize the PIE vector table with pointers to the shell Interrupt

        //Enable Global Interrupt (INTM) and realtime interrupt (DBGM)
        EINT;
        ERTM;

        //Enable interrupt function
        #if CAN_RECEICE_MSG_INTERRUPT==ENABLE
            Interrupt_register(INT_CANA0, &canISR);
            Interrupt_enable(INT_CANA0);
            CAN_enableGlobalInterrupt(CANA_BASE, CAN_GLOBAL_INT_CANINT0);
           // CAN_enableTestMode(CANA_BASE, CAN_TEST_EXL);
        #endif
        // Initialize the transmit message object used for sending CAN messages.
        // Message Object Parameters:
        //      Message Object ID Number: 1
        //      Message Identifier: 0x1
        //      Message Frame: Standard
        //      Message Type: Transmit
        //      Message ID Mask: 0x0
        //      Message Object Flags: Transmit Interrupt
        //      Message Data Length: 8 Bytes
        //
            CAN_setupMessageObject(CANA_BASE, TX_OBJ_ID, TX_MSG_ID, CAN_FRAME, CAN_MSG_OBJ_TYPE_TX, TX_MSG_ID, CAN_MSG_OBJ_TX_INT_ENABLE, MSG_DATA_LENGTH);

            //teste
            CAN_setupMessageObject(CANA_BASE, TX_OBJ_ID+1, TX_MSG_ID+1, CAN_FRAME, CAN_MSG_OBJ_TYPE_TX, TX_MSG_ID+1, CAN_MSG_OBJ_TX_INT_ENABLE, MSG_DATA_LENGTH);


        // Initialize the receive message object used for receiving CAN messages.
        // Message Object Parameters:
        //      Message Object ID Number: 2
        //      Message Identifier: 0x1
        //      Message Frame: Standard
        //      Message Type: Receive
        //      Message ID Mask: 0x0
        //      Message Object Flags: Receive Interrupt
        //      Message Data Length: 8 Bytes (Note that DLC field is a "don't care"
        //      for a Receive mailbox
        //
        CAN_setupMessageObject(CANA_BASE, RX_OBJ_ID, RX_MSG_ID, CAN_FRAME, CAN_MSG_OBJ_TYPE_RX, RX_MSG_ID, CAN_MSG_OBJ_RX_INT_ENABLE, MSG_DATA_LENGTH);
//        CAN_setupMessageObject(CANA_BASE, RX_OBJ_ID, 0, CAN_FRAME, CAN_MSG_OBJ_TYPE_RX, 0, CAN_MSG_OBJ_RX_INT_ENABLE | CAN_MSG_OBJ_NO_FLAGS, MSG_DATA_LENGTH);

        // Start CAN module operations
        CAN_startModule(CANA_BASE);
    #endif

    EDIS;
}
