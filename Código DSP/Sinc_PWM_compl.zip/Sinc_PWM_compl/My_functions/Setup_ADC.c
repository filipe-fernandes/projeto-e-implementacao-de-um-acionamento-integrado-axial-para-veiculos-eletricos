/*
 * Setup_ADC.c
 *
 *  Created on: 31 de jul de 2023
 *      Author: Projeto
 */

#include "My_config.h"


void Setup_ADC(void){

    SetVREF(ADC_ADCA, ADC_INTERNAL, ADC_VREF3P3);

    EALLOW;

    //Enable Clock
    CpuSysRegs.PCLKCR13.bit.ADC_A = 1;

    //Prescale de 2 (Clock de 60 MHz)
    AdcaRegs.ADCCTL2.bit.PRESCALE = 2;

    // Set pulse positions to late
    AdcaRegs.ADCCTL1.bit.INTPULSEPOS = 1;

    //Power up the ADC and then delay for 1 ms
    AdcaRegs.ADCCTL1.bit.ADCPWDNZ = 1;
    DELAY_US(1000);

    //Select Channel per SOC (ADCA)
    AdcaRegs.ADCSOC0CTL.bit.CHSEL  = 0;  //ADCIN0 -> SOC0
    AdcaRegs.ADCSOC1CTL.bit.CHSEL  = 1;  //ADCIN1 -> SOC1
    AdcaRegs.ADCSOC2CTL.bit.CHSEL  = 4;  //ADCIN4 -> SOC2
    AdcaRegs.ADCSOC3CTL.bit.CHSEL  = 5;  //ADCIN5 -> SOC3
    AdcaRegs.ADCSOC4CTL.bit.CHSEL  = 7;  //ADCIN7 -> SOC4
    AdcaRegs.ADCSOC5CTL.bit.CHSEL  = 8;  //ADCIN8 -> SOC5
    AdcaRegs.ADCSOC6CTL.bit.CHSEL  = 9;  //ADCIN9 -> SOC6
    AdcaRegs.ADCSOC7CTL.bit.CHSEL  = 10; //ADCIN10 -> SOC7
    AdcaRegs.ADCSOC8CTL.bit.CHSEL  = 11; //ADCIN11 -> SOC8
    AdcaRegs.ADCSOC9CTL.bit.CHSEL  = 12; //ADCIN12 -> SOC9
    AdcaRegs.ADCSOC10CTL.bit.CHSEL  = 15;//ADCIN15 -> SOC10

    //Sample window in SYSCLK cycles (ACQPS+1)*SYSCLK
    AdcaRegs.ADCSOC0CTL.bit.ACQPS  = 8;  //SOC0 (75 ns)
    AdcaRegs.ADCSOC1CTL.bit.ACQPS  = 8;  //SOC1 (75 ns)
    AdcaRegs.ADCSOC2CTL.bit.ACQPS  = 8;  //SOC2 (75 ns)
    AdcaRegs.ADCSOC3CTL.bit.ACQPS  = 8;  //SOC3 (75 ns)
    AdcaRegs.ADCSOC4CTL.bit.ACQPS  = 8;  //SOC4 (75 ns)
    AdcaRegs.ADCSOC5CTL.bit.ACQPS  = 8;  //SOC5 (75 ns)
    AdcaRegs.ADCSOC6CTL.bit.ACQPS  = 8;  //SOC6 (75 ns)
    AdcaRegs.ADCSOC7CTL.bit.ACQPS  = 8;  //SOC7 (75 ns)
    AdcaRegs.ADCSOC8CTL.bit.ACQPS  = 8;  //SOC8 (75 ns)
    AdcaRegs.ADCSOC9CTL.bit.ACQPS  = 8;  //SOC9 (75 ns)
    AdcaRegs.ADCSOC10CTL.bit.ACQPS  = 8; //SOC10 (75 ns)

    //Trigger Source
    AdcaRegs.ADCSOC0CTL.bit.TRIGSEL = ADC_TRIGGER_SOURCE;  //SOC0 -> Timer 0
    AdcaRegs.ADCSOC1CTL.bit.TRIGSEL = ADC_TRIGGER_SOURCE;  //SOC1 -> Timer 0
    AdcaRegs.ADCSOC2CTL.bit.TRIGSEL = ADC_TRIGGER_SOURCE;  //SOC2 -> Timer 0
    AdcaRegs.ADCSOC3CTL.bit.TRIGSEL = ADC_TRIGGER_SOURCE;  //SOC3 -> Timer 0
    AdcaRegs.ADCSOC4CTL.bit.TRIGSEL = ADC_TRIGGER_SOURCE;  //SOC4 -> Timer 0
    AdcaRegs.ADCSOC5CTL.bit.TRIGSEL = ADC_TRIGGER_SOURCE;  //SOC5 -> Timer 0
    AdcaRegs.ADCSOC6CTL.bit.TRIGSEL = ADC_TRIGGER_SOURCE;  //SOC6 -> Timer 0
    AdcaRegs.ADCSOC7CTL.bit.TRIGSEL = ADC_TRIGGER_SOURCE;  //SOC7 -> Timer 0
    AdcaRegs.ADCSOC8CTL.bit.TRIGSEL = ADC_TRIGGER_SOURCE;  //SOC8 -> Timer 0
    AdcaRegs.ADCSOC9CTL.bit.TRIGSEL = ADC_TRIGGER_SOURCE;  //SOC9 -> Timer 0
    AdcaRegs.ADCSOC10CTL.bit.TRIGSEL = ADC_TRIGGER_SOURCE; //SOC10 -> Timer 0

    AdcaRegs.ADCINTSEL1N2.bit.INT1SEL = 10; // End of SOC10 will set INT1 flag
    AdcaRegs.ADCINTSEL1N2.bit.INT1E = 1;    // Enable INT1 flag
    AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;  // Make sure INT1 flag is cleared

    //Enable ADCA1 interrupts
    #if ADC_FINISH_CONVERSION_INTERRUPT==ENABLE
        PieVectTable.ADCA1_INT = &AdcISR;
        PieCtrlRegs.PIEIER1.bit.INTx1 = 1;
        IER |=M_INT1;
    #endif
    EDIS;
}
