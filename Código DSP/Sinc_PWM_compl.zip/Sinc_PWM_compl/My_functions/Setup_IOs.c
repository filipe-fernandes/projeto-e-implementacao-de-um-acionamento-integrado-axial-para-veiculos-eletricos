/*
 * Setup_IOs.c
 *
 *  Created on: 13 de jul de 2023
 *      Author: Projeto
 */

#include "My_config.h"


void Setup_GPIOs(void)
{
    EALLOW;

    //Config Pin STBY witch digital output
    GpioCtrlRegs.GPAGMUX2.bit.GPIO24 = 0;
    GpioCtrlRegs.GPAMUX2.bit.GPIO24  = 0;
    GpioCtrlRegs.GPADIR.bit.GPIO24   = 1;

    //Config Pin RST witch digital output
    GpioCtrlRegs.GPAGMUX2.bit.GPIO16 = 0;
    GpioCtrlRegs.GPAMUX2.bit.GPIO16  = 0;
    GpioCtrlRegs.GPADIR.bit.GPIO16   = 1;

    //Config Pin LCKD witch digital input
    GpioCtrlRegs.GPHGMUX1.bit.GPIO228 = 0;
    GpioCtrlRegs.GPHMUX1.bit.GPIO228  = 0;
    GpioCtrlRegs.GPHAMSEL.bit.GPIO228 = 0;

    //Config Pin IN1 witch digital input
    GpioCtrlRegs.GPHGMUX2.bit.GPIO242 = 0;
    GpioCtrlRegs.GPHMUX2.bit.GPIO242  = 0;
    GpioCtrlRegs.GPHAMSEL.bit.GPIO242 = 0;

    //Config Pin IN2 witch digital input
    GpioCtrlRegs.GPHGMUX1.bit.GPIO224 = 0;
    GpioCtrlRegs.GPHMUX1.bit.GPIO224  = 0;
    GpioCtrlRegs.GPHAMSEL.bit.GPIO224  = 0;

    //Config Pin IN/OUT1
    GpioCtrlRegs.GPAGMUX1.bit.GPIO5 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO5  = 0;
    GpioCtrlRegs.GPADIR.bit.GPIO5   = DIR_IN_OUT1;

    //Config Pin IN/OUT2
    GpioCtrlRegs.GPAGMUX1.bit.GPIO6 = 0;
    GpioCtrlRegs.GPAMUX1.bit.GPIO6  = 0;
    GpioCtrlRegs.GPADIR.bit.GPIO6   = DIR_IN_OUT2;


    #if (DIR_IN_OUT3!=CAN || DIR_IN_OUT4!=CAN)
        //Config Pin IN/OUT3
        GpioCtrlRegs.GPBGMUX1.bit.GPIO32 = 0;
        GpioCtrlRegs.GPBMUX1.bit.GPIO32  = 0;
        GpioCtrlRegs.GPBDIR.bit.GPIO32   = DIR_IN_OUT3;

        //Config Pin IN/OUT4
        GpioCtrlRegs.GPBGMUX1.bit.GPIO33 = 0;
        GpioCtrlRegs.GPBMUX1.bit.GPIO33  = 0;
        GpioCtrlRegs.GPBDIR.bit.GPIO33   = DIR_IN_OUT4;
    #else
        //Config GPIO32 to CANA_TX
        GpioCtrlRegs.GPBGMUX1.bit.GPIO32 = 0b10;
        GpioCtrlRegs.GPBMUX1.bit.GPIO32  = 0b10;
        GpioCtrlRegs.GPBPUD.bit.GPIO32   = 1;   //Enable Pull-up

        //Config GOIO33 to CANA_RX
        GpioCtrlRegs.GPBGMUX1.bit.GPIO33 = 0b10;
        GpioCtrlRegs.GPBMUX1.bit.GPIO33  = 0b10;
        GpioCtrlRegs.GPBPUD.bit.GPIO33   = 1;    //Enable Pull-up
        GpioCtrlRegs.GPBQSEL1.bit.GPIO33 = 0b11; //Assynchronous Quali RX
    #endif


    #if (DIR_IN_OUT5!=JTAG || DIR_IN_OUT6!=JTAG)
        //Config Pin IN/OUT5
        GpioCtrlRegs.GPBGMUX1.bit.GPIO35 = 0;
        GpioCtrlRegs.GPBMUX1.bit.GPIO35  = 0;
        GpioCtrlRegs.GPBDIR.bit.GPIO35   = DIR_IN_OUT5;

        //Config Pin IN/OUT6
        GpioCtrlRegs.GPBGMUX1.bit.GPIO37 = 0;
        GpioCtrlRegs.GPBMUX1.bit.GPIO37  = 0;
        GpioCtrlRegs.GPBDIR.bit.GPIO37   = DIR_IN_OUT6;
    #endif

//############
//ALTERA��O COMENTEI A PARTE DE CIMA


    #if SCI==ENABLE
    //SCIA_RX
        GpioCtrlRegs.GPAGMUX2.bit.GPIO28 = 0b00;
        GpioCtrlRegs.GPAMUX2.bit.GPIO28  = 0b01;

    //SCIA_TX
        GpioCtrlRegs.GPAGMUX2.bit.GPIO29 = 0b00;
        GpioCtrlRegs.GPAMUX2.bit.GPIO29  = 0b01;
    #endif

    #if OUTPUT_PWM5==ENABLE
        //Config Pin PWM5 (ePWM1_A)
        GpioCtrlRegs.GPAGMUX1.bit.GPIO0 = 0b00;
        GpioCtrlRegs.GPAMUX1.bit.GPIO0  = 0b01;

    #endif

    #if OUTPUT_PWM4==ENABLE
        //Config Pin PWM4 (ePWM1_B)
        GpioCtrlRegs.GPAGMUX1.bit.GPIO1 = 0b00;
        GpioCtrlRegs.GPAMUX1.bit.GPIO1  = 0b01;
    #endif

    #if OUTPUT_PWM3==ENABLE
        //Config Pin PWM3 (ePWM2_A)
        GpioCtrlRegs.GPAGMUX1.bit.GPIO2 = 0b00;
        GpioCtrlRegs.GPAMUX1.bit.GPIO2  = 0b01;
    #endif

    #if OUTPUT_PWM2==ENABLE
        //Config Pin PWM2 (ePWM2_B)
        GpioCtrlRegs.GPAGMUX1.bit.GPIO3 = 0b00;
        GpioCtrlRegs.GPAMUX1.bit.GPIO3  = 0b01;
    #endif

    #if OUTPUT_PWM1==ENABLE
        //Config Pin PWM1 (ePWM3_A)
        GpioCtrlRegs.GPAGMUX1.bit.GPIO4 = 0b00;
        GpioCtrlRegs.GPAMUX1.bit.GPIO4  = 0b01;
    #endif

    #if OUTPUT_PWM6==ENABLE
        //Config Pin PWM6 (ePWM4_B)
        GpioCtrlRegs.GPAGMUX1.bit.GPIO7 = 0b00;
        GpioCtrlRegs.GPAMUX1.bit.GPIO7  = 0b01;
    #endif

    EDIS;
}




